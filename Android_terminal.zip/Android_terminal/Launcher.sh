cd /storage/emulated/0/Android_terminal/Android_terminal/LIB
python AndroidTerminal.py