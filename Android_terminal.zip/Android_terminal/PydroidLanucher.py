#Launcher
import os
os.system("python /storage/emulated/0/Android_terminal/Android_terminal/LIB/AndroidTerminal.py")
quit()